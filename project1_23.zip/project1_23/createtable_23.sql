DROP DATABASE IF EXISTS moviedb;
create DATABASE moviedb;




create table   moviedb.stars(
    id integer primary key auto_increment,
    first_name varchar(50) not null ,
    last_name varchar(50) not null ,
    dob date,
    photo_url varchar(200) 
	);
    
    
    create table   moviedb.movies(
		id integer primary key auto_increment,
        title varchar(100) not null,
		year_release integer not null ,
		director varchar(100) not null, 
		banner_url varchar(200), 
		trailer_url varchar(200)
        
    	);
     
    
	create table   moviedb.stars_in_movies ( 
		star_id integer not null ,
		movie_id integer not null,
		foreign key (star_id) references moviedb.stars(id) on delete cascade on update no action,
		foreign key (movie_id) references moviedb.movies(id) on delete cascade on update no action
    
    );
    
    
    create table   moviedb.genres (
    id integer primary key auto_increment,
    name varchar(32) not null
    
    
    );
    
    
    create table  moviedb.genres_in_movies(
		genre_id integer not null,
        movie_id integer not null,
        foreign key (genre_id) references moviedb.genres(id) on delete cascade on update no action,
        foreign key (movie_id) references moviedb.movies(id) on delete cascade on update no action
       
       );
		
      create table   moviedb.creditcards (
	id varchar(20) not null,
	first_name varchar(50) not null,
	last_name varchar(50) not null,
	expiration date not null,
    primary key(id)
    );
    
    
   
    create table  moviedb.customers  (
		id  integer primary key auto_increment,
		first_name varchar(50) not null,
		last_name varchar(50) not null,
		cc_id varchar(20) not null ,
		address varchar(200) not null,
		email varchar(50) not null,
		password varchar(20) not null,
        constraint foreign key (cc_id) references moviedb.creditcards(id) on update no action on delete cascade  
    
    );
    
		
    
    
    create table   moviedb.sales(
		id  integer primary key auto_increment,
        customer_id integer not null,
        movie_id integer not null,
		sale_date date not null,
		constraint foreign key(customer_id) references moviedb.customers(id) on delete cascade on update no action,
        constraint foreign key(movie_id) references moviedb.movies(id) on delete cascade on update no action
       
        );
    
    
  
         
       
       
       
