Follow this instructions 

1) unzip the zip file in ubuntu using the command 
shell>unzip project123.zip -d /destination_folder absolute address
2)use cd command in ubuntu to go the fold unzip folder
3)shell>sudo chmod 666 data_23.sql
4)shell>sudo chmod 666 createtable_23.sql
5)shell>mysql -u root -p
6)mysql>create database moviedb
7)mysql>exit
8)shell>sudo mysql -u root -p -D moviedb < createtable_23.sql
9)shell>sudo mysql -u root -p -D moviedb < data_23.sql
10)shell>CLASSPATH=$CLASSPATH:/home/hdalali/workspace/Webapps_proj/src/com/webapps/proj1/mysql-connector-java-5.1.40-bin.jar
11)shell>export CLASSPATH
12)shell>sudo javac JDBC1.java
13)shell>java JDBC1
